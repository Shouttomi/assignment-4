import { userSignIn } from "./register2.js";

const signInButton = document.querySelector("#signInButton");

signInButton.addEventListener("click", userSignIn);